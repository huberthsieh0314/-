# Sed script that converts quotations, by replacing ASCII quotation marks
# with Unicode quotation marks and highlighting the quotations in bold face.
#
# Copyright (C) 2001-2026 Free Software Foundation, Inc.
# This file is free software; the Free Software Foundation
# gives unlimited permission to copy and/or distribute it,
# with or without modifications, as long as this notice is preserved.
# This file is offered as-is, without any warranty.
#
# Written by Bruno Haible.
#
s/"\([^"]*\)"/“\1”/g
s/`\([^`']*\)'/‘\1’/g
s/ '\([^`']*\)' / ‘\1’ /g
s/ '\([^`']*\)'$/ ‘\1’/g
s/^'\([^`']*\)' /‘\1’ /g
s/“”/""/g
s/“/“[1m/g
s/”/[0m”/g
s/‘/‘[1m/g
s/’/[0m’/g
